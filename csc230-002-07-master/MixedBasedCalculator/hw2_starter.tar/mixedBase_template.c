#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

/** The hexadecimal value for the characer, A */
#define HEX_VALUE_A 10

bool isDecimalDigit( int ch )
{

}

bool isHexDigit( int ch )
{

}

void skipSpace()
{

}

long getNumber()
{

}

int main()
{

  return EXIT_SUCCESS;
}

